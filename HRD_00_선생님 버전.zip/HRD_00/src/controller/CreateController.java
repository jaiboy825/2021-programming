package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import member.MemberDAO;

@WebServlet("/create")
public class CreateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String lastIdx = String.valueOf(MemberDAO.getLastUserIdx());
		request.setAttribute("idx", lastIdx);
		
		RequestDispatcher rd = request.getRequestDispatcher("/views/create.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		String custno = request.getParameter("custno");
		String custname = request.getParameter("custname");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String date = request.getParameter("date");
		String grade = request.getParameter("grade");
		String city = request.getParameter("city");
		
		
		String sql = "INSERT INTO member_tbl_02 (custno, custname, phone, address, joindate, grade, city) VALUES (?, ?, ?, ?, ?, ?, ?)";
		
		String result = String.valueOf(MemberDAO.execute(sql, custno, custname, phone, address, date, grade, city));
		
		request.setAttribute("idx", custno);
		request.setAttribute("result", result);
		
		RequestDispatcher rd = request.getRequestDispatcher("/views/create.jsp");
		rd.forward(request, response);
		
	}

}
