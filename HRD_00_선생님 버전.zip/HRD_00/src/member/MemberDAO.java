package member;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {
	
	public static Connection getConnection() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
//		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/xe", "hr", "hr");
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:59161/xe", "system", "oracle");
		return con;
	}
	
	public static int execute(String sql, String ...params) {
		PreparedStatement pstmt = null;
		try {
			pstmt = getConnection().prepareStatement(sql);
			for (int i = 0 ; i < params.length ; i++) {
				pstmt.setString(i + 1, params[i]);
			}
			return pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public static int getLastUserIdx() {
		PreparedStatement pstmt = null; 
		int idx = 0;
		String sql = "SELECT nvl(max(custno),0) custno FROM member_tbl_02";
		
		try {
			pstmt = getConnection().prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				idx = rs.getInt("custno") + 1;
			} 
		} catch (Exception e) {
			e.printStackTrace();
		}
		return idx;
	}
	
	public static List<MemberDTO> selectUserList() {
		PreparedStatement pstmt = null;
		List<MemberDTO> list = new ArrayList<>();
		
		String sql = "SELECT * FROM member_tbl_02 ORDER BY custno ASC";
		
		try {
			pstmt = getConnection().prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				MemberDTO dto = new MemberDTO();
				dto.setCustno(rs.getString("custno"));
				dto.setCustname(rs.getString("custname"));
				dto.setPhone(rs.getString("phone"));
				dto.setAddress(rs.getString("address"));
				dto.setJoindate(rs.getString("joindate"));
				dto.setGrade(rs.getString("grade"));
				dto.setCity(rs.getString("city"));
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public static List<MemberDTO> selectUserView() {
		PreparedStatement pstmt = null;
		List<MemberDTO> list = new ArrayList<>();
		
		String sql = "SELECT u.custno, u.custname, u.grade, SUM(m.pcost * m.amount) AS price FROM money_tbl_02 m JOIN (SELECT u.custno, u.custname, u.grade FROM member_tbl_02 u) u ON m.custno = u.custno GROUP BY m.custno, u.custno, u.custname, u.grade ORDER BY price DESC";
		try {
			pstmt = getConnection().prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()) {
				MemberDTO data = new MemberDTO();
				data.setCustno(rs.getString("custno"));
				data.setCustname(rs.getString("custname"));
				data.setGrade(rs.getString("grade"));
				data.setPrice(rs.getString("price"));
				list.add(data);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public static MemberDTO selectUser(String idx) {
		PreparedStatement pstmt = null;
		MemberDTO data = new MemberDTO();
		
		String sql = "SELECT * FROM member_tbl_02 WHERE custno = ?";
		
		try {
			pstmt = getConnection().prepareStatement(sql);
			pstmt.setString(1, idx);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				data.setCustno(rs.getString("custno"));
				data.setCustname(rs.getString("custname"));
				data.setPhone(rs.getString("phone"));
				data.setAddress(rs.getString("address"));
				data.setJoindate(rs.getString("joindate"));
				data.setGrade(rs.getString("grade"));
				data.setCity(rs.getString("city"));
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return data;
	}
}
