package com.yydh.myapp2;

import java.util.Map;

public class CollectionBean2 {
	private Map<String, String> addressList;
	
	public void setAddressList(Map<String, String> addressList) {
		this.addressList = addressList;
	}
	public Map<String, String> getAddressList(){
		return addressList;
	}

}
