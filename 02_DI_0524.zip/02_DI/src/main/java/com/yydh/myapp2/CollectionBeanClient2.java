package com.yydh.myapp2;

import java.util.Map;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class CollectionBeanClient2 {

	public static void main(String[] args) {
		AbstractApplicationContext factory = 
				new GenericXmlApplicationContext("applicationContext4.xml");
		CollectionBean2 bean = (CollectionBean2)factory.getBean("collectionBean");
		Map<String, String> addressList = (Map<String, String>)bean.getAddressList();
		for(String address : addressList.keySet()) {
			String value = addressList.get(address);
			System.out.println(address + " : ");
		}
		factory.close();
	}

}
