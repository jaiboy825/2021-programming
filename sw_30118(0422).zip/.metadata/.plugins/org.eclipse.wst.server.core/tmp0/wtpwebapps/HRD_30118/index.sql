create table tbl_cust_201004(
	p_no char(4) primary key,
	p_name varchar2(20),
	p_birth char(8),
	p_tel1 char(3),
	p_tel2 char(4),
	p_tel3 char(4),
	p_city char(2),
	p_gender char(1)
)
select * from TBL_CUST_201004;
insert into tbl_cust_201004 values('1001', '��浿', '20000101','010','1111','1111','10','F');
insert into tbl_cust_201004 values('1002', '�̱浿', '20000102','010','1111','2222','20','M');
insert into tbl_cust_201004 values('1003', '�ڱ浿', '20000103','010','1111','3333','30','F');
insert into tbl_cust_201004 values('1004', '�ű浿', '20000104','010','1111','4444','40','M');

create table tbl_order_201004(
	p_seno number(8),
	i_code char(4),
	p_no char(4),
	p_date date
)

create table tbl_injection_201004 (
	i_code char(5) primary key,
	i_name varchar2(20),
	i_age varchar2(20)
)

insert into tbl_injection_201004 values('A001', '�ڷγ����', '3�� ~ 100��'); 
insert into tbl_injection_201004 values('A002', '�ͷγ����', '4�� ~ 100��'); 
insert into tbl_injection_201004 values('A003', '�Էγ����', '5�� ~ 100��'); 
insert into tbl_injection_201004 values('A004', '���γ����', '6�� ~ 100��'); 

select c.i_code, c.i_name, count(b.p_seno) from TBL_ORDER_201004 b, TBL_INJECTION_201004 c where b.i_code = c.i_code  group by c.i_code, c.i_name order by c.i_code asc;

select b.p_seno, a.p_no, a.p_name, b.i_code, c.i_name, b.p_date from TBL_CUST_201004 a, TBL_ORDER_201004 b, TBL_INJECTION_201004 c where a.p_no = b.p_no and b.i_code = c.i_code order by a.p_no asc;

drop table tbl_cust_201004;
drop table tbl_order_201004;
drop table tbl_injection_201004;