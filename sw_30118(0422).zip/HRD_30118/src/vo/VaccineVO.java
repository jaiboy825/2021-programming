package vo;

public class VaccineVO {
	private String i_code;
	private String i_name;
	private int i_count;

	public String getI_code() {
		return i_code;
	}

	public void setI_code(String i_code) {
		this.i_code = i_code;
	}

	public String getI_name() {
		return i_name;
	}

	public void setI_name(String i_name) {
		this.i_name = i_name;
	}

	public int getI_count() {
		return i_count;
	}

	public void setI_count(int i_count) {
		this.i_count = i_count;
	}

}
