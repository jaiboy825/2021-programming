package vo;

public class OrderVO {
	private String p_seno;
	private String i_code;
	private String p_no;
	private String p_date;

	public String getP_seno() {
		return p_seno;
	}

	public void setP_seno(String p_seno) {
		this.p_seno = p_seno;
	}

	public String getI_code() {
		return i_code;
	}

	public void setI_code(String i_code) {
		this.i_code = i_code;
	}

	public String getP_no() {
		return p_no;
	}

	public void setP_no(String p_no) {
		this.p_no = p_no;
	}

	public String getP_date() {
		return p_date;
	}

	public void setP_date(String p_date) {
		this.p_date = p_date;
	}

}
