package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import vo.MemberVO;
import vo.OrderVO;
import vo.VaccineOrderVO;
import vo.VaccineVO;

public class MemberDAO {
	public Connection getConnection() {
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return conn;
	}

	public ArrayList<MemberVO> getMemberList() {
		ArrayList<MemberVO> list = new ArrayList<MemberVO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from tbl_cust_201004");
			rs = pstmt.executeQuery();
			while (rs.next()) {
				MemberVO vo = new MemberVO();
				vo.setP_no(rs.getString(1));
				vo.setP_name(rs.getString(2));
				vo.setP_birth(rs.getString(3));
				vo.setP_tel1(rs.getString(4));
				vo.setP_tel2(rs.getString(5));
				vo.setP_tel3(rs.getString(6));
				String city = "";
				switch (rs.getString(7)) {
				case "10":
					city = "����";
					break;
				case "20":
					city = "���";
					break;
				case "30":
					city = "�λ�";
					break;
				case "40":
					city = "�뱸";
					break;
				}
				vo.setP_city(city);
				String gender = "";
				switch (rs.getString(8)) {
				case "F":
					gender = "��";
					break;
				case "M":
					gender = "��";
					break;
				}
				vo.setP_gender(gender);
				
				list.add(vo);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	public int insertOrder(OrderVO vo) {
		int n = 0;
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("insert into tbl_order_201004 values(?,?,?,?)");
			pstmt.setString(1, vo.getP_seno());
			pstmt.setString(2, vo.getI_code());
			pstmt.setString(3, vo.getP_no());
			pstmt.setString(4, vo.getP_date());
			n = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n;

	}
	
	public ArrayList<VaccineOrderVO> getOrderList(){
		ArrayList<VaccineOrderVO> list = new ArrayList<VaccineOrderVO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select b.p_seno, a.p_no, a.p_name, b.i_code, c.i_name, b.p_date from TBL_CUST_201004 a, TBL_ORDER_201004 b, TBL_INJECTION_201004 c where a.p_no = b.p_no and b.i_code = c.i_code ");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				VaccineOrderVO vo = new VaccineOrderVO();
				vo.setP_seno(rs.getString(1));
				vo.setP_no(rs.getString(2));
				vo.setP_name(rs.getString(3));
				vo.setI_code(rs.getString(4));
				vo.setI_name(rs.getString(5));
				vo.setP_date(rs.getDate(6));
				list.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
	public ArrayList<VaccineVO> getVaccineList(){
		ArrayList<VaccineVO> list = new ArrayList<VaccineVO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select c.i_code, c.i_name, count(b.p_seno) from TBL_ORDER_201004 b, TBL_INJECTION_201004 c where b.i_code = c.i_code  group by c.i_code, c.i_name order by c.i_code asc");
			rs = pstmt.executeQuery();
			while(rs.next()) {
				VaccineVO vo = new VaccineVO();
				vo.setI_code(rs.getString(1));
				vo.setI_name(rs.getString(2));
				vo.setI_count(rs.getInt(3));
				list.add(vo);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return list;
	}
}
