package factory;

public abstract class Product {
    public abstract void use();
}
