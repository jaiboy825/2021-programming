package facade;

public class Main {
    public static void main(String[] args) {
        PageMaker.makeWelcomePage("youngjin@youngjin.com", "src/facade/welcome.html");
    }
}
